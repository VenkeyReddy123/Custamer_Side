   
   import ele from '../src/Data/Products/e.png'
   import clo from '../src/Data/Products/c.png'
   import foo from '../src/Data/Products/fo.png'
   import Acc from '../src/Data/Products/ac.png'
   import Bea from '../src/Data/Products/be.png'
   import Fur from '../src/Data/Products/fur.png'
   
   import Boo  from '../src/Data/Products/bo.png'
   import Spo from '../src/Data/Products/sp.png'
   
   import Hel from '../src/Data/Products/hel.png'
   import To from '../src/Data/Products/tg.png'
   import Ho from '../src/Data/Products/ho.png'
  
   
   
   
   export const  Electrinics = ["Mobiles", "Laptops", "Cameras", "Audio", "Video", "Telivision", "Electric Devices"] 

   
   export   const Clothing =  ["T-shirts", "Dresses", "Shirts", "Pants", "Jeans", "Skirts", "Jackets", "Sweaters", "Blouses", "Shorts"]


   export const Footware =["Boots", "Sneakers", "Sandals", "Flats", "Heels", "Athletic Shoes", "Slippers", "Loafers", "Oxfords", "Espadrilles"]


   export  const Accesories=[ "Jewelry","Bags & Purses","Hats & Caps", "Scarves & Shawls","Sunglasses","Watches","Belts","Gloves",
     "Hair Accessories","Wallets & Cardholders","Socks & Hosiery","Ties & Bowties","Umbrellas","Keychains","Handkerchiefs","Eyewear Accessories"]


     export  const Beauty_PersonCare =[ "Skincare","Haircare","Makeup","Fragrance","Bath & Body","Men's Grooming","Nail Care"
     ,"Tools & Accessories","Personal Care Appliances","Oral Care","Shaving & Hair Removal","Health & Wellness","Gift Sets"]


     export const Home_Kitchen =[  "Cookware","Bakeware", "Kitchen Utensils & Gadgets", "Cutlery & Knife Accessories", "Food Storage & Organization",
     "Kitchen Appliances","Dining & Entertaining","Home Décor","Bedding","Bath","Furniture","Home Improvement","Cleaning Supplies",
     "Laundry","Heating, Cooling & Air Quality",]

     export   const Furniture =[ "Living Room Furniture","Bedroom Furniture","Dining Room Furniture","Home Office Furniture","Kids' Furniture","Entryway Furniture","Outdoor Furniture",
      "Accent Furniture", "Mattresses & Box Springs", "Furniture Sets", "Futons, Frames & Covers", "Kitchen & Dining Room Tables",
      "Chairs","Sofas & Couches","Ottomans","TV Stands & Entertainment Centers","Bookcases",]


      export   const Books_Music =[ "Books","Ebooks","Audiobooks","Magazines","Comics & Graphic Novels","Textbooks","Movies","TV Shows","Music",
      "Vinyl Records","CDs & DVDs","Digital Music","Concert Tickets","Sheet Music & Songbooks"]


      export   const Sports =[ "Athletic Clothing","Athletic Shoes","Team Sports","Exercise & Fitness","Outdoor Recreation","Camping & Hiking",
      "Cycling","Water Sports","Winter Sports","Golf","Tennis & Racquet Sports","Running","Yoga","Hunting & Fishing","Fan Shop","Sports Collectibles","Sports Memorabilia","Sports Equipment",]


      export   const Health =[ "Vitamins & Supplements","Personal Care","Health Care","Fitness & Nutrition","Medical Supplies & Equipment","Wellness & Relaxation",
      "Sports Nutrition","First Aid","Weight Management","Health Monitors","Diet & Nutrition","Alternative Medicine","Mobility Aids & Equipment","Braces, Splints & Supports","Occupational & Physical Therapy",]


      export   const Toys_Games =[ "Dolls & Accessories","Puzzles","Building Toys","Outdoor Play","Ride-On Toys","Remote Control & Play Vehicles","Stuffed Animals & Plush",
      "Arts & Crafts","Learning & Educational Toys","Board Games","Card Games","Electronic Games","Party Supplies",
      "Kids' Electronics","Musical Instruments","Tricycles, Scooters & Wagons","Video Games",]
      export const Catigories=["Electronics","Clothing","Footware","Accessories","Beauty&Person","Home&Kichen","Furniture","Books,Movies&Musics","Sports","Health","Toys&Games"]
      export const Images=[ele,clo,foo,Acc,Bea,Ho,Fur,Boo,Spo,Hel,To]
      export const  Shop_by=[
        {
           "Name":"Electronics",  
           "Img":ele
        },
        {
            "Name":"Clothing",
            "Img":clo
         },
         {
            "Name":"Footwear",
            "Img":foo
         },
         {
            "Name":"Accessories",
            "Img":Acc
         },
         {
            "Name":"Beauty",
            "Img":Bea
         },
         {
            "Name":"Home & Kitchen",
            "Img":Ho
         },
         
         {
            "Name":"Furniture",
            "Img":Fur
         },
         {
            "Name":"Books & Music",
            "Img":Boo
         }
         , {
          "Name":"Sports",
          "Img":Spo
       },
        {
        "Name":"Helth",
        "Img":Hel
       },
       {
        "Name":"Toys & Games",
        "Img":To
     }
    ]