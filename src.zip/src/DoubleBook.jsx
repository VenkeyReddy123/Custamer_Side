import React from 'react'

const DoubleBook = () => {
  return (
    <>
    
    </>
  )
}

export default DoubleBook