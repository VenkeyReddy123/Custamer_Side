import Ele from '../Category_Asses/e1.jpg'
import Cloth from '../Category_Asses/c1.jpg'
import Hom from '../Category_Asses/h1.jpg'
import Fur from '../Category_Asses/Fur1.webp'
import Hel from '../Category_Asses/hel1.jpg'
import Auto from '../Category_Asses/Auto1.png'
import Toys from '../Category_Asses/Toys.jpg'


export const  Shop_by=[
    {
       "Name":"Electronics",  
       "Img":Ele
    },
    {
        "Name":"Home Appliances",
        "Img":Hom
     },
     {
        "Name":"Clothing and Apparel",
        "Img":Cloth
     },
     {
        "Name":"Furniture and Home Decor",
        "Img":Fur
     },
     {
        "Name":"Health and Personal Care",
        "Img":Hel
     },
     {
        "Name":"Automotive",
        "Img":Auto
     },
     {
        "Name":"Toys and Games",
        "Img":Toys
     }
]