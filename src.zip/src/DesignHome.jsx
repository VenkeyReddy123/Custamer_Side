import React from 'react'
import DSidebar from './DSidebar'

const DesignHome = () => {
  return (
   <>
     <div className="sidebar">
      
      <DSidebar/>
    </div>
   </>
  )
}

export default DesignHome