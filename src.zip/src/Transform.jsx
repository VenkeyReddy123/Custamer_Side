import React from 'react'
import './T.css'

const Transform = () => {
  return (
    <>
      <div className='yaaaa'>
                  <h1>Hii</h1>
                  <h2>Hlo</h2>
                  <h3>Byee</h3>
      </div>
    </>
  )
}

export default Transform